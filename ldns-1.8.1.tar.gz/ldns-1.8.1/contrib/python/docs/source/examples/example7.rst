Generate public/private key pair
=======================================

This example shows how generate keys for DNSSEC (i.e. for signing a zone file according DNSSECbis).

.. literalinclude:: ../../../examples/ldns-keygen.py
   :language: python

